def mostrar_menu():
    print("\nMENU:")
    print("1. INSERTAR")
    print("2. MODIFICAR")
    print("3. ELIMINAR")
    print("4. BUSCAR ELEMENTO")
    print("5. MENOR")
    print("6. MAYOR")
    print("7. SALIR")

def insertar(lista):
    try:
        numero = int(input("Ingrese el número a insertar: "))
        lista.append(numero)
        print("Número insertado.")
    except ValueError:
        print("Entrada inválida.")

def modificar(lista):
    try:
        viejo = int(input("Número a modificar: "))
        if viejo in lista:
            nuevo = int(input("Nuevo valor: "))
            index = lista.index(viejo)
            lista[index] = nuevo
            print("Número modificado.")
        else:
            print("Número no encontrado.")
    except ValueError:
        print("Entrada inválida.")

def eliminar(lista):
    try:
        numero = int(input("Número a eliminar: "))
        lista.remove(numero)
        print("Número eliminado.")
    except ValueError:
        print("Número no encontrado o entrada inválida.")

def buscar(lista):
    try:
        numero = int(input("Número a buscar: "))
        if numero in lista:
            print(f"Número encontrado en la posición {lista.index(numero)}.")
        else:
            print("Número no encontrado.")
    except ValueError:
        print("Entrada inválida.")

def menor(lista):
    if lista:
        print("El número menor es:", min(lista))
    else:
        print("La lista está vacía.")

def mayor(lista):
    if lista:
        print("El número mayor es:", max(lista))
    else:
        print("La lista está vacía.")

# Programa principal
lista_numeros = []

while True:
    mostrar_menu()
    opcion = input("Seleccione una opción (1-7): ")

    if opcion == '1':
        insertar(lista_numeros)
    elif opcion == '2':
        modificar(lista_numeros)
    elif opcion == '3':
        eliminar(lista_numeros)
    elif opcion == '4':
        buscar(lista_numeros)
    elif opcion == '5':
        menor(lista_numeros)
    elif opcion == '6':
        mayor(lista_numeros)
    elif opcion == '7':
        print("Saliendo del programa.")
        break
    else:
        print("Opción inválida.")

    print("Lista actual:", lista_numeros)
